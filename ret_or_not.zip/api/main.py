"""FastAPI backend for the research dashboard.

LD-1 boundaries (requirement §10):
- ``/ask`` answers with the ADAPTIVE workflow only (decision engine ->
  selected path). Reference answers and oracle labels are never exposed to
  the decision engine and never included in the payload of the live mode.
- ``/ask?mode=cross`` performs cross-verification: both paths run, retrieved
  passages and scores are shown, and - only when offline evaluation data is
  available for the question - the decision-correctness flag is attached and
  clearly marked as evaluation-only.
- ``/evaluate/run`` executes a batch of the four-policy experiment.
- ``/evaluate/summary|export`` expose aggregates and per-question CSV/JSON.

Tests call the modules directly; this HTTP layer is a thin, optional shell
(the CLI pipeline works without it).
"""

from __future__ import annotations

import io
import csv
import os
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse

from adaptive_qa.config import load_config, resolve_path
from adaptive_qa.experiment import ExperimentRunner
from adaptive_qa.eval.outcome import label_outcome
from adaptive_qa.pipeline import Pipeline
from adaptive_qa.serialization import read_jsonl, read_json

app = FastAPI(title="Adaptive QA Research Dashboard", version="0.1.0")

_STATE: Dict[str, Any] = {"runner": None, "eval_rows": None}


def _runner() -> ExperimentRunner:
    if _STATE["runner"] is None:
        cfg = load_config(os.environ.get("ADAPTIVE_QA_CONFIG", "configs/default.json"))
        _STATE["runner"] = ExperimentRunner(cfg)
    runner: ExperimentRunner = _STATE["runner"]
    return runner


def _eval_rows():
    if _STATE["eval_rows"] is None:
        path_cfg = resolve_path("runs")
        # latest run's per_question.jsonl if present, else None
        candidates = sorted(path_cfg.glob("*/per_question.jsonl"))
        _STATE["eval_rows"] = read_jsonl(str(candidates[-1])) if candidates else []
    return _STATE["eval_rows"]


@app.get("/")
def index():
    return FileResponse(str(resolve_path("dashboard/index.html")))


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/ask")
def ask(payload: Dict[str, Any], mode: str = Query(default="adaptive")) -> JSONResponse:
    """Live adaptive answering; ``mode=cross`` adds cross-verification.

    In adaptive mode the ONLY executed work is decision + selected path. In
    cross mode both paths execute; retrieved passages, timings and (when a
    saved eval run contains the question) the decision-correctness flag are
    returned and marked ``evaluation_only``.
    """
    question = (payload or {}).get("question", "").strip()
    if not question:
        raise HTTPException(status_code=400, detail="question required")

    runner = _runner()
    if mode not in ("adaptive", "cross"):
        raise HTTPException(status_code=400, detail="mode must be adaptive|cross")

    pipeline = Pipeline(
        retriever=runner.retriever,
        method_a=runner.method_a,
        method_b=runner.method_b,
        decision_engine=runner.decision_engine,
        top_k=runner.top_k,
    )

    if mode == "adaptive":
        rec = pipeline.run_adaptive("api-live", question)
        return JSONResponse({"mode": mode, "record": rec.to_dict()})

    rec = pipeline.run_cross_verify("api-cross", question)

    # Offline evaluation linkage (clearly labeled, never fed to the engine)
    eval_link = None
    for row in _eval_rows():
        if row.get("question", "").strip().lower() == question.lower():
            qrec = None
            for q2 in runner.records_eval:
                if q2.question.strip().lower() == question.lower():
                    qrec = q2
                    break
            if qrec is not None:
                outcome = label_outcome(qrec, rec.answer_a, rec.answer_b)
                # decision correctness vs the SAVED run's decision on the
                # same question (scored offline; consistent with the oracle
                # tie-break: 'similar' counts as correct either way, since
                # both methods are practically equivalent there)
                expected = None
                if outcome.label == "retrieval_better":
                    expected = "RETRIEVE"
                elif outcome.label == "no_retrieval_better":
                    expected = "DO_NOT_RETRIEVE"
                saved_decision = row.get("decision")
                decision_correct = (
                    (expected is None)
                    or (saved_decision is None)
                    or (saved_decision == expected)
                )
                eval_link = {
                    "evaluation_only": True,
                    "question_id": row.get("question_id"),
                    "reference_answer": qrec.answer,
                    "gold_titles": list(qrec.gold_titles),
                    "saved_run_decision": saved_decision,
                    "decision_correct": bool(decision_correct),
                    "outcome_label": outcome.label,
                    "quality_a": outcome.quality_a,
                    "quality_b": outcome.quality_b,
                    "note": "Computed offline against saved runs; never shown to the decision engine.",
                }
            break

    return JSONResponse(
        {
            "mode": mode,
            "record": rec.to_dict(),
            "evaluation_link": eval_link,
        }
    )


@app.post("/evaluate/run")
def evaluate_run(payload: Dict[str, Any] = None) -> JSONResponse:
    n = int(((payload or {}).get("limit")) or 0)
    runner = _runner()
    questions = runner.records_eval
    if n > 0:
        questions = questions[:n]
    artifacts = runner.evaluate_questions(questions)
    from adaptive_qa.eval.charts import write_all

    write_all(artifacts.summary, artifacts.run_dir)
    return JSONResponse({"run_dir": artifacts.run_dir, "summary": artifacts.summary})


@app.get("/evaluate/summary")
def evaluate_summary() -> JSONResponse:
    candidates = sorted(resolve_path("runs").glob("*/summary.json"))
    if not candidates:
        raise HTTPException(status_code=404, detail="no completed runs; POST /evaluate/run first")
    return JSONResponse(read_json(str(candidates[-1])))


_CHART_NAMES = {"quality_vs_latency.png", "quality_vs_cost.png", "retrieval_rate.png"}


@app.get("/evaluate/chart/{name}")
def evaluate_chart(name: str):
    """Serve a chart PNG from the most recent completed run (whitelist)."""
    if name not in _CHART_NAMES:
        raise HTTPException(status_code=404, detail="unknown chart")
    runs = sorted(resolve_path("runs").glob("*/summary.json"))
    if not runs:
        raise HTTPException(status_code=404, detail="no completed runs")
    png = runs[-1].parent / name
    if not png.exists():
        raise HTTPException(status_code=404, detail="chart not generated in latest run")
    return FileResponse(str(png), media_type="image/png")


def _rows_to_csv(rows: List[Dict[str, Any]]) -> str:
    if not rows:
        return ""
    fields = [
        "question_id", "question", "split", "policy", "decision", "decision_score",
        "primary_method",
    ]
    # outsourced columns for per-method evaluation
    extra = [
        "em_a", "f1_a", "em_b", "f1_b", "outcome_label", "delta",
        "decision_ms", "retrieval_ms", "gen_a_ms", "gen_b_ms",
        "adaptive_e2e_ms", "cross_verify_ms", "evaluation_ms",
        "answer_a_text", "answer_b_text", "primary_answer_text", "retrieval_title_1",
        "retrieval_score_1", "reference_answer",
    ]
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=fields + extra, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        out = {
            "question_id": row.get("question_id"),
            "question": row.get("question"),
            "split": row.get("split"),
            "policy": row.get("policy"),
            "decision": row.get("decision"),
            "decision_score": row.get("decision_score"),
            "primary_method": row.get("primary_method"),
        }
        outcome = row.get("outcome") or {}
        for k in ("em_a", "f1_a", "em_b", "f1_b", "delta"):
            out[k] = outcome.get(k)
        out["outcome_label"] = outcome.get("label")
        for k in ("decision_ms", "retrieval_ms", "gen_a_ms", "gen_b_ms", "adaptive_e2e_ms", "cross_verify_ms", "evaluation_ms"):
            out[k] = row.get(k)
        out["answer_a_text"] = (row.get("answer_a") or {}).get("text")
        out["answer_b_text"] = (row.get("answer_b") or {}).get("text")
        out["primary_answer_text"] = (row.get("primary_answer") or {}).get("text")
        hits = row.get("retrieval_hits") or []
        if hits:
            out["retrieval_title_1"] = hits[0].get("title")
            out["retrieval_score_1"] = hits[0].get("score")
        out["reference_answer"] = outcome.get("reference_answer")
        writer.writerow(out)
    return buf.getvalue()


@app.get("/evaluate/export")
def evaluate_export(format: str = Query(default="csv")):
    rows = _eval_rows()
    if not rows:
        raise HTTPException(status_code=404, detail="no per_question.jsonl run yet")
    if format == "json":
        return JSONResponse(rows)
    if format == "csv":
        csv_text = _rows_to_csv(rows)
        return StreamingResponse(
            io.StringIO(csv_text),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=per_question.csv"},
        )
    raise HTTPException(status_code=400, detail="format must be csv|json")
